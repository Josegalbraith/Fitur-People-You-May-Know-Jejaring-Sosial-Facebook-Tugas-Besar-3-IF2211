## Penjelasan Singkat Algoritma

Algoritma DFS:
Tetapkan simpul yang akan dicek menjadi simpul awal
Cari simpul-simpul hidupnya dan simpan simpul-simpul tersebut pada bagian awal daftar simpul hidup
Simpan jumlah simpul hidup pada simpul yang sedang dicek pada daftar yang menyatakan jumlah simpul hidup per simpul yang dikunjungi.
Simpan nilai pada simpul yang sedang dicek pada daftar simpul-simpul yang sudah dikunjungi
Ubah nilai simpul yang akan dicek menjadi simpul pertama pada daftar simpul hidup dan hilangkan simpul tersebut dari daftar simpul hidup.
Ulangi langkah pertama hingga simpul yang sedang dicek adalah simpul tujuan atau daftar simpul hidup menjadi kosong (yang menandakan tidak ada jalur DFS) dan kurangi jumlah simpul hidup pada daftar yang menyimpannya sejumlah 1 pada setiap iterasi dimulai dari simpul sebelum ditemukannya simpul yang tidak memiliki simpul hidup dihitung mundur hingga simpul yang jika jumlah simpul hidupnya lebih dari 1 jika dikurangi 1 jika ditemukan simpul yang tidak memiliki simpul hidup
Simpul-simpul yang memiliki jumlah lebih dari 0 akan membentuk jalur pencarian DFS jika simpul-simpul tersebut diurut berdasarkan urutan pencarian yang lebih dulu.

Algoritma BFS: 
Tetapkan simpul awal pencarian
“Kunjungi” simpul awal. Kunjungi berarti: 1) menambahkan simpul ke antrian, dan 2) mencatat jalur menuju simpul. Simpul yang sudah dikunjungi tidak boleh dikunjungi lagi.
Keluarkan simpul awal dari antrian.
Kunjungi (tambah ke antrian + catat jalur) satu per satu simpul yang bertetangga dengan simpul awal. Kunjungan dilakukan sesuai aturan tertentu (biasanya urutan abjad nama simpul).
Keluarkan simpul pertama yang dimasukkan ke antrian.
Kunjungi (tambah ke antrian + catat jalur) satu per satu simpul yang bertetangga dengan simpul yang telah dikeluarkan.
Ulangi langkah 5 dan 6 hingga antrian kembali kosong.
Telah diperoleh jalur dari simpul awal ke semua simpul lainnya secara BFS.


## Instalasi tertentu

Tidak perlu melakukan instalasi jika hanya ingin menjalankan program.
Untuk men-compile program, dibutuhkan Visual Studio. Visual Studio harus sudah berisikan workload ".NET desktop development" dan library MSAGL (Microsoft Automatic Graph Layout).
Workload ".NET desktop development" langsung bisa di-install lewat Visual Studio Installer.
Library MSAGL perlu di-download via NuGet Package Manager. Langkah-langkah instalasi MSAGL:
- buka Visual Studio,
- pilih menu Tools -> NuGet Package Manager -> Package Manager Console pada toolbar,
- tuliskan 4 baris perintah di bawah ini pada console yang terbuka:
    Install-Package AutomaticGraphLayout -Version 1.1.11
    Install-Package AutomaticGraphLayout.Drawing -Version 1.1.11
    Install-Package AutomaticGraphLayout.WpfGraphControl -Version 1.1.11
    Install-Package AutomaticGraphLayout.GraphViewerGDI -Version 1.1.11

## Cara menggunakan program

Jika ingin meng-compile program, buka file src/Tubes2_13519022.sln pada Visual Studio, kemudian compile dengan menekan memilih menu Build -> Build Solution (Ctrl+Shift+B) atau Build -> Build Tubes2_13519022 (Ctrl+B). Hasil kompilasi bisa ditemukan pada folder src/Tubes2_13519022/bin/Debug (atau Release, tergantung Build Settings anda)/netcoreapp3.1/
Jika ingin menjalankan program yang sudah jadi, cukup jalankan file Tubes2_13519022.exe pada folder bin.

## Author / identitas pembuat

Jose Galbraith Hasintongan (13519022)
Feralezer Leonard Gorga Tampubolon (13519062)
Moses Ananta (13519076)